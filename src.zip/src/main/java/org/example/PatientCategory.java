package org.example;

public enum PatientCategory{
    INPATIENT,
    OUTPATIENT,
    EMERGENCY,
}